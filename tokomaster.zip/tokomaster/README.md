# Tokol
Toko Online DistroIT With PHP native, MySQLi and Bootstrap 3
This code is build with PHP 5.5, MySQli and bootstrap 3
Its free code for development or learning about basic online strore.
No guaranted for this code, fell free for developing with this code.

For more info visit http://www.hakkoblogs.com/2015/02/membuat-toko-online-sederhana-dengan.html#.VmisHNKLTDc

For demo go to this link http://tokol.niqoweb.com
